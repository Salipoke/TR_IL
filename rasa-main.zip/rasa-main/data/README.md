These are some example training data files for a simple bot in the restaurant domain. 
They are in the format of the services rasa NLU can emulate, e.g. when you download an export
of your app from one of these services it should look like one of these files.


[examples/rasa](examples/rasa): examples in the native rasa NLU format

[examples/luis](examples/luis): in LUIS format

[examples/wit](examples/wit): in wit format

[examples/api](examples/api): this is a dir and in Dialogflow format
