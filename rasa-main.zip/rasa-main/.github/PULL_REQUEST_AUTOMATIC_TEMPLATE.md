:bulb: This pull request was created automatically to merge a release branch back into the `main` branch.

The changes you see here should have already been reviewed by someone, and shouldn't need an extra
review. Nonetheless, if you notice something that needs to be addressed, please reach out to the person
responsible for the original changes. In case additional changes need to be made, they need to target the release branch
(not this pull request nor `main`).

:auto_rickshaw: This PR should be merged automatically once it has been approved. If it doesn't happen:
- [ ] Handle merge conflicts
- [ ] Fix build errors
